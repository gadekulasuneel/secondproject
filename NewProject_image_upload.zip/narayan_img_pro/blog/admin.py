from django.contrib import admin

# Register your models here.
from .models import Student

class StudentAdmin(admin.ModelAdmin):
    list_display = ['sno','sname','sloc','image','profile']

admin.site.register(Student,StudentAdmin)