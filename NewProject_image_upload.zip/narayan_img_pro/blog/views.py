from django.shortcuts import render,redirect

# Create your views here.
from .models import Student
from .forms import StudentForm
from django.http import HttpResponse


def Student_view(request):
    if request.method=="POST":
        form=StudentForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('display')
        else:
            return HttpResponse('Invalid Error')
    else:
        form=StudentForm()
        return render(request,'student.html',{'form':form})

def Display_view(request):
    fdata=Student.objects.all()
    return render(request,'display.html',{'fdata':fdata})
